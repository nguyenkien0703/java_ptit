/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package com.mycompany.bai1.j07007;


import java.io.IOException;

public class Main
{
    public static void main(String[] args) throws IOException
    {
        WordSet ws = new WordSet("VANBAN.in");
        System.out.println(ws);
    }
}